import { useEffect, useMemo, useRef, useState } from 'react'
import {
  Activity, AppWindow, Archive, Calculator, Check, ChevronDown, Clock3, Command,
  File, FileText, Folder, FolderOpen, HardDrive, HelpCircle, Info, LayoutGrid,
  Maximize2, Minus, Monitor, MoreHorizontal, Move, Palette, Plus, Power, RefreshCw,
  Search, Settings, ShieldCheck, Terminal, Trash2, X, Download, Upload, Save,
  Moon, Sun, Type, Bot, ExternalLink
} from 'lucide-react'

type AppId = 'notes'|'calculator'|'files'|'terminal'|'settings'|'about'
type VFile = { id:string; name:string; path:string; kind:'file'|'folder'; content?:string; updated:number }
type Win = { id:string; app:AppId; title:string; x:number; y:number; w:number; h:number; z:number; minimized:boolean; maximized:boolean }
type Prefs = { theme:'dark'|'light'; wallpaper:'grid'|'radar'|'plain'; fontSize:number; accent:string }
const DB_NAME='ares-desktop-db', STORE='files'
const defaults: VFile[] = [
  {id:'folder-docs',name:'Documents',path:'/',kind:'folder',updated:Date.now()},
  {id:'folder-projects',name:'Projects',path:'/',kind:'folder',updated:Date.now()},
  {id:'readme',name:'WELCOME.txt',path:'/Documents',kind:'file',content:'ARES Desktop へようこそ。\\n\\nこれはブラウザ内で動作する仮想OSの試作版です。\\n\\n・メモ帳で文章を作成\\n・ファイルマネージャーで仮想ファイルを管理\\n・ターミナルで help と入力\\n・設定から外観を変更\\n・設定でJSONバックアップを作成\\n\\n実際のOSコマンドは実行しません。',updated:Date.now()},
  {id:'plan',name:'ARES_PLAN.txt',path:'/Projects',kind:'file',content:'開発ロードマップ\\n\\n[✓] デスクトップとウィンドウ管理\\n[✓] メモ帳・電卓・仮想ファイル\\n[✓] 安全な仮想ターミナル\\n[✓] 設定とバックアップ\\n[ ] AIアシスタント（将来の拡張）\\n[ ] Web検索・証拠管理（将来の拡張）',updated:Date.now()}
]
function openDb():Promise<IDBDatabase>{
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,1)
    req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE,{keyPath:'id'})}
    req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)
  })
}
async function dbGetAll():Promise<VFile[]>{
  const db=await openDb();return new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readonly').objectStore(STORE).getAll();r.onsuccess=()=>resolve(r.result as VFile[]);r.onerror=()=>reject(r.error)})
}
async function dbPutMany(items:VFile[]){
  const db=await openDb();return new Promise<void>((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite'),s=tx.objectStore(STORE);items.forEach(x=>s.put(x));tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error)})
}
async function dbClear(){const db=await openDb();return new Promise<void>((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).clear();tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error)})}
const appMeta:Record<AppId,{title:string;icon:any;subtitle:string}> = {
  notes:{title:'メモ帳',icon:FileText,subtitle:'TEXT EDITOR'},calculator:{title:'電卓',icon:Calculator,subtitle:'CALCULATOR'},
  files:{title:'ファイルマネージャー',icon:FolderOpen,subtitle:'VIRTUAL FILE SYSTEM'},
  terminal:{title:'ターミナル',icon:Terminal,subtitle:'ARES SHELL'},
  settings:{title:'設定',icon:Settings,subtitle:'SYSTEM PREFERENCES'},about:{title:'システム情報',icon:Info,subtitle:'SYSTEM INFORMATION'}
}
const defaultPrefs:Prefs={theme:'dark',wallpaper:'grid',fontSize:14,accent:'#67d5e8'}
function App(){
  const [files,setFiles]=useState<VFile[]>([])
  const [prefs,setPrefs]=useState<Prefs>(()=>{try{return {...defaultPrefs,...JSON.parse(localStorage.getItem('ares-prefs')||'{}')}}catch{return defaultPrefs}})
  const [wins,setWins]=useState<Win[]>([])
  const [active,setActive]=useState<string|null>(null)
  const [menu,setMenu]=useState(false)
  const [search,setSearch]=useState('')
  const [clock,setClock]=useState(new Date())
  const [toast,setToast]=useState('')
  const [dbReady,setDbReady]=useState(false)
  const [dbError,setDbError]=useState('')
  const [notesText,setNotesText]=useState('')
  const [notesFileId,setNotesFileId]=useState('')
  const [terminalInput,setTerminalInput]=useState('')
  const [terminalLog,setTerminalLog]=useState<string[]>(['ARES Desktop Shell [Version 0.1.0]','安全な内部コマンドのみを実行します。','help と入力するとコマンド一覧を表示します。'])
  const [calcDisplay,setCalcDisplay]=useState('0')
  const [calcExpr,setCalcExpr]=useState('')
  const [currentPath,setCurrentPath]=useState('/')
  const [selectedFile,setSelectedFile]=useState<string|null>(null)
  const [newName,setNewName]=useState('')
  const [showCreate,setShowCreate]=useState(false)
  const [createKind,setCreateKind]=useState<'file'|'folder'>('file')
  const [drag,setDrag]=useState<{id:string;mode:'move'|'resize';dx:number;dy:number;startX:number;startY:number;startW:number;startH:number}|null>(null)
  const fileInput=useRef<HTMLInputElement>(null)
  const activeWin=wins.find(w=>w.id===active)
  useEffect(()=>{let alive=true;(async()=>{try{let stored=await dbGetAll();if(!stored.length){await dbPutMany(defaults);stored=await dbGetAll()}if(alive){setFiles(stored);setDbReady(true)}}catch(e){setDbError(String(e));setFiles(defaults);setDbReady(true)}})();return()=>{alive=false}},[])
  useEffect(()=>{const t=setInterval(()=>setClock(new Date()),1000);return()=>clearInterval(t)},[])
  useEffect(()=>{localStorage.setItem('ares-prefs',JSON.stringify(prefs));document.documentElement.dataset.theme=prefs.theme;document.documentElement.style.setProperty('--accent',prefs.accent);document.documentElement.style.setProperty('--app-font-size',`${prefs.fontSize}px`)},[prefs])
  useEffect(()=>{if(dbReady&&files.length)dbPutMany(files).catch(e=>setDbError(String(e)))},[files,dbReady])
  useEffect(()=>{if(!toast)return;const t=setTimeout(()=>setToast(''),2800);return()=>clearTimeout(t)},[toast])
  const notify=(s:string)=>setToast(s)
  const persistFiles=async(next:VFile[])=>{setFiles(next);try{await dbPutMany(next)}catch(e){setDbError(String(e));notify('保存に失敗しました。バックアップを作成してください。')}}
  const launch=(app:AppId)=>{
    const existing=wins.find(w=>w.app===app)
    if(existing){setWins(old=>old.map(w=>w.id===existing.id?{...w,minimized:false,z:Math.max(0,...old.map(a=>a.z))+1}:w));setActive(existing.id);setMenu(false);return}
    const id=`${app}-${Date.now()}`
    const n=Math.max(0,...wins.map(w=>w.z))+1
    const mobile=window.innerWidth<700
    const w:Win={id,app,title:appMeta[app].title,x:mobile?8:90+(wins.length%5)*34,y:mobile?8:48+(wins.length%5)*30,w:mobile?window.innerWidth-16:Math.min(app==='files'?720:app==='terminal'?650:560,window.innerWidth-40),h:mobile?Math.max(330,window.innerHeight-110):Math.min(470,window.innerHeight-150),z:n,minimized:false,maximized:mobile}
    setWins(old=>[...old,w]);setActive(id);setMenu(false)
    if(app==='notes'&&!notesText){const f=files.find(x=>x.id==='readme');setNotesText(f?.content||'');setNotesFileId(f?.id||'')}
  }
  const focus=(id:string)=>{setActive(id);setWins(old=>old.map(w=>w.id===id?{...w,z:Math.max(0,...old.map(a=>a.z))+1,minimized:false}:w))}
  const close=(id:string)=>{setWins(old=>old.filter(w=>w.id!==id));if(active===id)setActive(wins.filter(w=>w.id!==id&&!w.minimized).sort((a,b)=>b.z-a.z)[0]?.id||null)}
  const patchWin=(id:string,p:Partial<Win>)=>setWins(old=>old.map(w=>w.id===id?{...w,...p}:w))
  const saveNote=async()=>{
    const id=notesFileId||`note-${Date.now()}`
    const old=files.find(f=>f.id===id)
    const item:VFile={id,name:old?.name||'NOTE.txt',path:old?.path||'/Documents',kind:'file',content:notesText,updated:Date.now()}
    await persistFiles(old?files.map(f=>f.id===id?item:f):[...files,item]);setNotesFileId(id);notify('メモを保存しました')
  }
  const createItem=async()=>{
    const name=newName.trim();if(!name){notify('名前を入力してください');return}
    if(files.some(f=>f.path===currentPath&&f.name===name)){notify('同じ名前が存在します');return}
    const item:VFile={id:`item-${Date.now()}-${Math.random().toString(36).slice(2,6)}`,name,path:currentPath,kind:createKind,content:createKind==='file'?'':undefined,updated:Date.now()}
    await persistFiles([...files,item]);setNewName('');setShowCreate(false);setSelectedFile(item.id);notify(createKind==='file'?'ファイルを作成しました':'フォルダを作成しました')
  }
  const deleteSelected=async()=>{if(!selectedFile)return;const f=files.find(x=>x.id===selectedFile);if(!f)return;if(!confirm(`「${f.name}」を削除しますか？`))return;await persistFiles(files.filter(x=>x.id!==selectedFile&&x.path!==`${f.path==='/'?'':f.path}/${f.name}`));setSelectedFile(null);notify('削除しました')}
  const renameSelected=async()=>{const f=files.find(x=>x.id===selectedFile);const name=newName.trim();if(!f||!name)return;if(files.some(x=>x.path===f.path&&x.name===name)){notify('同じ名前が存在します');return}await persistFiles(files.map(x=>x.id===f.id?{...x,name,updated:Date.now()}:x));setNewName('');notify('名前を変更しました')}
  const openSelected=()=>{const f=files.find(x=>x.id===selectedFile);if(!f)return;if(f.kind==='folder'){setCurrentPath(`${f.path==='/'?'':f.path}/${f.name}`);setSelectedFile(null)}else{setNotesText(f.content||'');setNotesFileId(f.id);launch('notes')}}
  const backup=()=>{const blob=new Blob([JSON.stringify({format:'ARES-Desktop-Backup',version:1,exportedAt:new Date().toISOString(),prefs,files},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`ares-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(url);notify('バックアップを書き出しました')}
  const restore=(file?:File)=>{if(!file)return;const reader=new FileReader();reader.onload=async()=>{try{const d=JSON.parse(String(reader.result));if(d.format!=='ARES-Desktop-Backup'||!Array.isArray(d.files))throw new Error('ARES形式のバックアップではありません');if(!confirm('現在の仮想ファイルと設定をバックアップ内容で置き換えますか？'))return;await dbClear();await dbPutMany(d.files);setFiles(d.files);if(d.prefs)setPrefs({...defaultPrefs,...d.prefs});notify('バックアップを復元しました')}catch(e){notify(`復元エラー: ${String(e)}`)}};reader.readAsText(file)}
  const runCommand=()=>{
    const raw=terminalInput.trim(),parts=raw.split(/\s+/),cmd=parts[0]?.toLowerCase(),arg=parts.slice(1).join(' ')
    let lines:string[]=[]
    switch(cmd){
      case 'help': lines=['利用可能なコマンド:','help             コマンド一覧','date             現在日時','clear            画面を消去','apps             アプリ一覧','open notes       メモ帳を開く','open files       ファイル管理を開く','open calculator  電卓を開く','open settings    設定を開く','ls               現在の仮想フォルダを表示','pwd              現在の仮想パス','echo <文字列>    文字列を表示'];break
      case 'date':lines=[new Date().toLocaleString('ja-JP')];break
      case 'clear':setTerminalLog([]);setTerminalInput('');return
      case 'apps':lines=Object.values(appMeta).map(a=>a.title);break
      case 'pwd':lines=[currentPath];break
      case 'ls':lines=files.filter(f=>f.path===currentPath).map(f=>`${f.kind==='folder'?'[DIR] ':'      '}${f.name}`);if(!lines.length)lines=['(空のフォルダ)'];break
      case 'echo':lines=[arg];break
      case 'open':{const map:Record<string,AppId>={notes:'notes',files:'files',calculator:'calculator',settings:'settings',terminal:'terminal',about:'about'};if(map[arg]){launch(map[arg]);lines=[`${appMeta[map[arg]].title} を起動しました。`]}else lines=['使い方: open notes | files | calculator | settings | about'];break}
      case '':return
      default:lines=[`不明なコマンド: ${cmd}`,'help と入力してコマンド一覧を確認してください。']
    }
    setTerminalLog(old=>[...old,`ares> ${raw}`,...lines]);setTerminalInput('')
  }
  const calculate=(key:string)=>{
    if(key==='C'){setCalcDisplay('0');setCalcExpr('');return}
    if(key==='⌫'){setCalcDisplay(v=>v.length>1?v.slice(0,-1):'0');return}
    if(key==='='){try{if(!/^[0-9+\-*/(). %]+$/.test(calcDisplay))throw new Error();const result=Function(`"use strict";return (${calcDisplay})`)();if(!Number.isFinite(result))throw new Error();setCalcExpr(calcDisplay+' =');setCalcDisplay(String(Number(result.toFixed(8))))}catch{setCalcExpr('入力を確認してください')}return}
    setCalcDisplay(v=>v==='0'&&/[0-9.]/.test(key)?key:v+key)
  }
  const visibleFiles=files.filter(f=>f.path===currentPath&&(f.name.toLowerCase().includes(search.toLowerCase())))
  const IconFor=({app,size=17}:{app:AppId;size?:number})=>{const I=appMeta[app].icon;return <I size={size}/>}
  const appButtons:AppId[]=['notes','calculator','files','terminal','settings','about']
  const appButton=(id:AppId)=><button className="app-launch" key={id} onClick={()=>launch(id)}><span className="app-icon"><IconFor app={id} size={20}/></span><span>{appMeta[id].title}</span></button>
  return <div className={`os ${prefs.theme}`} style={{fontSize:prefs.fontSize}} onPointerMove={e=>{if(!drag)return;const w=wins.find(x=>x.id===drag.id);if(w&&!w.maximized){if(drag.mode==='move')patchWin(w.id,{x:Math.max(0,e.clientX-drag.dx),y:Math.max(0,e.clientY-drag.dy)});else patchWin(w.id,{w:Math.max(300,Math.min(window.innerWidth-16,drag.startW+e.clientX-drag.startX)),h:Math.max(220,Math.min(window.innerHeight-75,drag.startH+e.clientY-drag.startY))})}}} onPointerUp={()=>setDrag(null)}>
    <div className={`desktop wallpaper-${prefs.wallpaper}`}>
      <div className="topline"><div className="brand"><span className="brand-mark"><Activity size={17}/></span><span>ARES<span className="brand-light"> / DESKTOP</span></span><span className="build-tag">BUILD 0.1</span></div><div className="top-status"><span className="status-dot"/><span>SYSTEM READY</span><span className="top-sep">|</span><span>{dbReady?'LOCAL STORAGE '+(dbError?'DEGRADED':'ONLINE'):'INITIALIZING'}</span></div></div>
      <div className="desktop-icons">{(['files','notes','terminal','calculator'] as AppId[]).map(id=><button className="desktop-icon" key={id} onDoubleClick={()=>launch(id)} onClick={()=>setActive(null)}><span className="desktop-icon-box"><IconFor app={id} size={23}/></span><span>{appMeta[id].title}</span></button>)}</div>
      <div className="hero"><div className="eyebrow"><span className="status-dot"/> PERSONAL COMPUTING ENVIRONMENT</div><h1>OPERATIONS<br/><span>DESKTOP</span></h1><p>統合型ブラウザ・ワークスペース</p><div className="hero-line"/><div className="hero-meta"><div><small>PLATFORM</small><b>WEB / LOCAL</b></div><div><small>SESSION</small><b>{clock.toLocaleTimeString('ja-JP',{hour12:false})}</b></div><div><small>STORAGE</small><b>{dbError?'CHECK REQUIRED':dbReady?'AVAILABLE':'LOADING'}</b></div></div></div>
      <div className="system-card"><div className="card-head"><span>システム状態</span><MoreHorizontal size={16}/></div><div className="sys-row"><span><HardDrive size={15}/> 仮想ストレージ</span><b>{dbError?'警告':dbReady?'正常':'確認中'}</b></div><div className="sys-track"><span style={{width:dbError?'35%':'18%'}}/></div><div className="sys-row"><span><ShieldCheck size={15}/> セキュリティ</span><b>保護モード</b></div><div className="sys-row"><span><AppWindow size={15}/> 起動中のアプリ</span><b>{wins.length}</b></div><div className="card-foot">LOCAL-FIRST ENVIRONMENT</div></div>
      {wins.filter(w=>!w.minimized).map(w=><section key={w.id} className={`window ${active===w.id?'focused':''} ${w.maximized?'maximized':''}`} style={{left:w.maximized?8:w.x,top:w.maximized?8:w.y,width:w.maximized?'calc(100% - 16px)':w.w,height:w.maximized?'calc(100% - 92px)':w.h,zIndex:w.z+10}} onPointerDown={()=>focus(w.id)}>
        <header className="window-title" onPointerDown={e=>{if((e.target as HTMLElement).closest('button'))return;focus(w.id);if(!w.maximized){const r=(e.currentTarget.parentElement as HTMLElement).getBoundingClientRect();setDrag({id:w.id,mode:'move',dx:e.clientX-r.left,dy:e.clientY-r.top,startX:e.clientX,startY:e.clientY,startW:r.width,startH:r.height});(e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId)}}}>
          <span className="window-app-icon"><IconFor app={w.app} size={16}/></span><span className="window-name">{w.title}</span><span className="window-subtitle">{appMeta[w.app].subtitle}</span>
          <div className="window-actions"><button title="最小化" onClick={()=>patchWin(w.id,{minimized:true})}><Minus size={14}/></button><button title="最大化/元に戻す" onClick={()=>patchWin(w.id,{maximized:!w.maximized})}><Maximize2 size={13}/></button><button title="閉じる" className="close-btn" onClick={()=>close(w.id)}><X size={15}/></button></div>
        </header>
        <div className="window-body">
          {w.app==='notes'&&<div className="notes-app"><div className="app-toolbar"><span className="file-label"><FileText size={14}/>{files.find(f=>f.id===notesFileId)?.name||'UNTITLED.txt'}</span><button className="primary small" onClick={saveNote}><Save size={14}/> 保存</button><button className="small" onClick={()=>{setNotesText('');setNotesFileId('')}}><Plus size={14}/> 新規</button><button className="small" onClick={()=>launch('files')}><Folder size={14}/> ファイルを開く</button></div><textarea value={notesText} onChange={e=>setNotesText(e.target.value)} placeholder="ここに文章を入力..." spellCheck={false}/><div className="statusbar"><span>UTF-8</span><span>{notesText.length} 文字</span><span>自動保存なし — 保存ボタンを押してください</span></div></div>}
          {w.app==='calculator'&&<div className="calculator-app"><div className="calc-label">ARES CALCULATOR</div><div className="calc-expression">{calcExpr||'四則演算'}</div><div className="calc-display">{calcDisplay}</div><div className="calc-grid">{['C','(',')','⌫','7','8','9','/','4','5','6','*','1','2','3','-','0','.','=','+'].map(k=><button key={k} className={`${['/','*','-','+','='].includes(k)?'calc-op':''} ${k==='='?'calc-equal':''} ${k==='C'?'calc-clear':''}`} onClick={()=>calculate(k)}>{k}</button>)}</div></div>}
          {w.app==='files'&&<div className="files-app"><aside className="file-sidebar"><div className="sidebar-title">場所</div><button className={currentPath==='/'?'selected':''} onClick={()=>setCurrentPath('/')}><HardDrive size={15}/> このPC</button><button className={currentPath==='/Documents'?'selected':''} onClick={()=>setCurrentPath('/Documents')}><Folder size={15}/> Documents</button><button className={currentPath==='/Projects'?'selected':''} onClick={()=>setCurrentPath('/Projects')}><Folder size={15}/> Projects</button><div className="sidebar-bottom"><ShieldCheck size={14}/> 仮想領域のみ</div></aside><div className="file-main"><div className="file-toolbar"><button onClick={()=>setCurrentPath(currentPath==='/'?'/':currentPath.split('/').slice(0,-1).join('/')||'/')}><ChevronDown size={14} className="back-arrow"/> 戻る</button><div className="path-box">{currentPath}</div><button onClick={()=>setShowCreate(true)}><Plus size={14}/> 新規</button><button onClick={deleteSelected} disabled={!selectedFile}><Trash2 size={14}/></button></div><div className="file-list-head"><span>名前</span><span>種類</span><span>更新日時</span></div><div className="file-list">{visibleFiles.map(f=><button key={f.id} className={`file-row ${selectedFile===f.id?'selected':''}`} onClick={()=>setSelectedFile(f.id)} onDoubleClick={()=>{setSelectedFile(f.id);if(f.kind==='folder')openSelected();else{setNotesText(f.content||'');setNotesFileId(f.id);launch('notes')}}}><span className="file-name">{f.kind==='folder'?<Folder size={17}/>:<FileText size={17}/>}<span>{f.name}</span></span><span>{f.kind==='folder'?'フォルダ':'テキスト'}</span><span>{new Date(f.updated).toLocaleDateString('ja-JP')}</span></button>)}{!visibleFiles.length&&<div className="empty-state"><FolderOpen size={28}/><span>このフォルダは空です</span></div>}</div>{showCreate&&<div className="modal-backdrop"><div className="modal"><h3>新規作成</h3><div className="segmented"><button className={createKind==='file'?'on':''} onClick={()=>setCreateKind('file')}>ファイル</button><button className={createKind==='folder'?'on':''} onClick={()=>setCreateKind('folder')}>フォルダ</button></div><input autoFocus value={newName} onChange={e=>setNewName(e.target.value)} placeholder={createKind==='file'?'例：memo.txt':'例：Research'} onKeyDown={e=>e.key==='Enter'&&createItem()}/><div className="modal-actions"><button onClick={()=>setShowCreate(false)}>キャンセル</button><button className="primary" onClick={createItem}>作成</button></div></div></div>}<div className="file-footer">{visibleFiles.length} 個の項目 <span>{selectedFile?files.find(f=>f.id===selectedFile)?.name:'項目を選択'}</span><button disabled={!selectedFile} onClick={openSelected}>開く</button><button disabled={!selectedFile} onClick={()=>{const f=files.find(x=>x.id===selectedFile);if(f){setNewName(f.name);setShowCreate(false);const n=prompt('新しい名前を入力してください',f.name);if(n?.trim()){setNewName(n);persistFiles(files.map(x=>x.id===f.id?{...x,name:n.trim(),updated:Date.now()}:x))}}}}>名前変更</button></div></div></div>}
          {w.app==='terminal'&&<div className="terminal-app"><div className="terminal-top"><span className="terminal-dot red"/><span className="terminal-dot yellow"/><span className="terminal-dot green"/> <span>ares-shell — safe mode</span></div><div className="terminal-output">{terminalLog.map((line,i)=><div key={i} className={line.startsWith('ares>')?'command-line':''}>{line}</div>)}</div><form className="terminal-input" onSubmit={e=>{e.preventDefault();runCommand()}}><span>ares &gt;</span><input value={terminalInput} onChange={e=>setTerminalInput(e.target.value)} autoComplete="off" spellCheck={false} aria-label="コマンド入力"/><button type="submit"><ExternalLink size={14}/></button></form></div>}
          {w.app==='settings'&&<div className="settings-app"><div className="settings-intro"><Settings size={24}/><div><h2>設定</h2><p>ARES Desktopの外観とデータを管理します。</p></div></div><div className="setting-section"><h3><Palette size={16}/> 外観</h3><div className="setting-row"><div><b>テーマ</b><small>画面全体の配色</small></div><div className="segmented"><button className={prefs.theme==='dark'?'on':''} onClick={()=>setPrefs(p=>({...p,theme:'dark'}))}><Moon size={14}/> ダーク</button><button className={prefs.theme==='light'?'on':''} onClick={()=>setPrefs(p=>({...p,theme:'light'}))}><Sun size={14}/> ライト</button></div></div><div className="setting-row"><div><b>壁紙</b><small>デスクトップ背景</small></div><select value={prefs.wallpaper} onChange={e=>setPrefs(p=>({...p,wallpaper:e.target.value as Prefs['wallpaper']}))}><option value="grid">グリッド</option><option value="radar">レーダー</option><option value="plain">シンプル</option></select></div><div className="setting-row"><div><b>文字サイズ</b><small>{prefs.fontSize}px</small></div><input type="range" min="12" max="18" value={prefs.fontSize} onChange={e=>setPrefs(p=>({...p,fontSize:Number(e.target.value)}))}/></div><div className="setting-row"><div><b>アクセントカラー</b><small>操作部の強調色</small></div><input type="color" value={prefs.accent} onChange={e=>setPrefs(p=>({...p,accent:e.target.value}))}/></div></div><div className="setting-section"><h3><Archive size={16}/> バックアップと復元</h3><p className="muted">仮想ファイルと設定をJSON形式で保存します。重要なデータは定期的に書き出してください。</p><div className="backup-actions"><button className="primary" onClick={backup}><Download size={15}/> バックアップを書き出す</button><button onClick={()=>fileInput.current?.click()}><Upload size={15}/> 復元</button><input ref={fileInput} type="file" accept=".json,application/json" hidden onChange={e=>restore(e.target.files?.[0])}/></div>{dbError&&<p className="error-text">保存領域のエラー: {dbError}</p>}</div><div className="setting-section"><h3><ShieldCheck size={16}/> プライバシー</h3><p className="muted">データはこのブラウザ内に保存されます。現バージョンでは外部AI APIや外部サーバーに送信しません。ブラウザデータの消去に備えてバックアップを保管してください。</p></div></div>}
          {w.app==='about'&&<div className="about-app"><div className="about-logo"><Activity size={35}/></div><h1>ARES Desktop</h1><p className="about-version">VIRTUAL OPERATING ENVIRONMENT / 0.1.0</p><p>ブラウザ上で動作する、ローカルファーストの仮想デスクトップ環境。</p><div className="about-grid"><div><small>PLATFORM</small><b>Web / React</b></div><div><small>STORAGE</small><b>IndexedDB</b></div><div><small>NETWORK</small><b>AI未接続</b></div><div><small>SECURITY</small><b>内部コマンド限定</b></div></div><div className="about-note"><Info size={15}/> ARES Desktopは本物のOSではありません。仮想ファイルはこのブラウザの保存領域に保存されます。</div></div>}
        </div>
        {!w.maximized&&<div className="resize-handle" onPointerDown={e=>{e.stopPropagation();focus(w.id);const r=(e.currentTarget.parentElement as HTMLElement).getBoundingClientRect();setDrag({id:w.id,mode:'resize',dx:0,dy:0,startX:e.clientX,startY:e.clientY,startW:r.width,startH:r.height});(e.currentTarget as HTMLElement).setPointerCapture(e.pointerId)}} title="ウィンドウサイズ調整"><Move size={11}/></div>}
      </section>)}
      {menu&&<div className="start-menu"><div className="start-head"><div className="user-chip"><Activity size={19}/></div><div><b>ARES Desktop</b><small>ローカルワークスペース</small></div></div><div className="start-search"><Search size={15}/><input placeholder="アプリを検索..." value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="start-label">アプリケーション</div><div className="start-apps">{appButtons.filter(id=>appMeta[id].title.toLowerCase().includes(search.toLowerCase())).map(appButton)}</div><div className="start-bottom"><span><ShieldCheck size={14}/> セーフモード</span><button title="メニューを閉じる" onClick={()=>setMenu(false)}><X size={15}/></button></div></div>}
      <footer className="taskbar"><button className={`start-button ${menu?'active':''}`} onClick={()=>setMenu(!menu)}><LayoutGrid size={18}/><span>ARES</span></button><div className="taskbar-apps">{wins.map(w=><button key={w.id} className={`task-app ${active===w.id&&!w.minimized?'active':''} ${w.minimized?'minimized':''}`} onClick={()=>w.minimized||active===w.id?patchWin(w.id,{minimized:!w.minimized}):focus(w.id)}><IconFor app={w.app} size={15}/><span>{w.title}</span><i/></button>)}</div><div className="taskbar-right"><span className="task-online"><span className="status-dot"/> LOCAL</span><button className="clock" onClick={()=>launch('about')}><b>{clock.toLocaleTimeString('ja-JP',{hour:'2-digit',minute:'2-digit',hour12:false})}</b><small>{clock.toLocaleDateString('ja-JP',{month:'2-digit',day:'2-digit'})}</small></button></div></footer>
      {toast&&<div className="toast"><Check size={15}/>{toast}</div>}
      {dbError&&<div className="db-warning"><Info size={14}/> ストレージに問題があります。設定からバックアップをご確認ください。</div>}
    </div>
  </div>
}
export default App
